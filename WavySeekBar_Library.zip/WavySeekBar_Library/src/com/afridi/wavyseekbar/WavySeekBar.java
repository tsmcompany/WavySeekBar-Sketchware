package com.afridi.wavyseekbar; 

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.AppCompatSeekBar;

public class WavySeekBar extends AppCompatSeekBar {

    private WaveDrawable waveDrawable;
    private final Handler handler = new Handler();
    private boolean userTouching = false;
    private Runnable syncRunnable;
    private long seekBlockTime = 0;
    private MediaPlayer attachedMediaPlayer;

    // Default customizable properties
    private int currentDynamicColor = Color.rgb(255, 60, 170);
    private float trackThicknessDp = 8f;
    private float glowRadiusDp = 6f;

    public WavySeekBar(Context context) {
        super(context);
        init(context, null);
    }

    public WavySeekBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public WavySeekBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        if (attrs != null) {
            // Parse XML attributes dynamically
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.WavySeekBar);
            currentDynamicColor = a.getColor(R.styleable.WavySeekBar_waveColor, currentDynamicColor);
            trackThicknessDp = a.getDimension(R.styleable.WavySeekBar_trackThickness, trackThicknessDp);
            glowRadiusDp = a.getDimension(R.styleable.WavySeekBar_glowRadius, glowRadiusDp);
            a.recycle();
        }

        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        int height = dp(65);
        setMinimumHeight(height);

        int thumbSize = dp(20);
        int thumbRadius = thumbSize / 2;

        setPadding(thumbRadius, dp(18), thumbRadius, dp(18));
        setSplitTrack(false);

        waveDrawable = new WaveDrawable();
        setProgressDrawable(waveDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.WHITE);
        thumb.setSize(thumbSize, thumbSize);
        thumb.setStroke(dp(2), adjustAlpha(currentDynamicColor, 0.5f));

        setThumb(thumb);
        setThumbOffset(thumbRadius);

        // Native touch listener to handle sync debounce
        setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {}

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar seekBar) {
                userTouching = true;
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar seekBar) {
                userTouching = false;
                seekBlockTime = System.currentTimeMillis() + 800;
                if (attachedMediaPlayer != null) {
                    attachedMediaPlayer.seekTo(getProgress());
                }
            }
        });
    }

    // Connect external MediaPlayer directly to the View
    public void attachMediaPlayer(MediaPlayer mp) {
        this.attachedMediaPlayer = mp;
        startSync();
    }

    public void setDynamicColor(int color) {
        this.currentDynamicColor = color;
        if (waveDrawable != null) {
            waveDrawable.invalidateSelf();
        }
        if (getThumb() instanceof GradientDrawable) {
            ((GradientDrawable) getThumb()).setStroke(dp(2), adjustAlpha(color, 0.5f));
        }
    }

    private void startSync() {
        if (syncRunnable != null) {
            handler.removeCallbacks(syncRunnable);
        }

        syncRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    if (attachedMediaPlayer != null) {
                        int duration = attachedMediaPlayer.getDuration();
                        int position = attachedMediaPlayer.getCurrentPosition();

                        if (duration > 0) {
                            if (getMax() != duration) {
                                setMax(duration);
                            }
                            if (!userTouching && System.currentTimeMillis() > seekBlockTime) {
                                if (position >= 0 && position <= duration) {
                                    if (Math.abs(getProgress() - position) > 50) {
                                        setProgress(position);
                                    }
                                }
                            }
                        }
                        if (waveDrawable != null) {
                            waveDrawable.setPlaying(attachedMediaPlayer.isPlaying());
                        }
                    }
                } catch (Exception e) {
                    if (waveDrawable != null) waveDrawable.setPlaying(false);
                }
                handler.postDelayed(this, 40);
            }
        };
        handler.post(syncRunnable);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (syncRunnable != null) {
            handler.removeCallbacks(syncRunnable);
        }
    }

    private class WaveDrawable extends Drawable {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Path wave1 = new Path();
        private final Path wave2 = new Path();
        private final Path wave3 = new Path();

        private float phase = 0f;
        private boolean playing = false;

        WaveDrawable() {
            trackPaint.setStyle(Paint.Style.FILL);
            progressPaint.setStyle(Paint.Style.FILL);

            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeCap(Paint.Cap.ROUND);
            glowPaint.setMaskFilter(new BlurMaskFilter(glowRadiusDp, BlurMaskFilter.Blur.NORMAL));

            wavePaint.setStyle(Paint.Style.STROKE);
            wavePaint.setStrokeCap(Paint.Cap.ROUND);
        }

        void setPlaying(boolean value) {
            playing = value;
            invalidateSelf();
        }

        @Override
        public int getIntrinsicHeight() {
            return dp(65);
        }

        @Override
        public void draw(Canvas canvas) {
            int width = getBounds().width();
            if (width <= 0) return;

            float density = getResources().getDisplayMetrics().density;
            float centerY = getBounds().exactCenterY();
            
            float trackHeight = trackThicknessDp; 
            float trackTop = centerY - trackHeight / 2f;
            float trackBottom = centerY + trackHeight / 2f;

            trackPaint.setColor(Color.argb(60, 255, 255, 255)); 
            canvas.drawRoundRect(0, trackTop, width, trackBottom, trackHeight / 2f, trackHeight / 2f, trackPaint);

            int max = getMax();
            if (max <= 0) return;

            float progress = getProgress() / (float) max;
            progress = Math.max(0f, Math.min(1f, progress));

            float startX = 2f * density;
            float endX = width - 2f * density;
            float progressWidth = startX + (endX - startX) * progress;

            int color1 = currentDynamicColor;
            int color2 = shiftColor(currentDynamicColor, 0.8f);
            int color3 = shiftColor(currentDynamicColor, 1.2f);

            if (progressWidth > startX) {
                progressPaint.setColor(adjustAlpha(color1, 0.4f));
                canvas.drawRoundRect(startX, trackTop, progressWidth, trackBottom, trackHeight / 2f, trackHeight / 2f, progressPaint);
            }

            if (progressWidth > startX + 2f) {
                float maxAmplitude = 10f * density; 

                buildWave(wave1, startX, progressWidth, centerY - 1.5f * density, maxAmplitude, 0.055, phase, 1.0);
                buildWave(wave2, startX, progressWidth, centerY - 0.5f * density, maxAmplitude * 0.8f, 0.075, phase * 1.15f, 1.35);
                buildWave(wave3, startX, progressWidth, centerY - 2.5f * density, maxAmplitude * 0.6f, 0.095, phase * 0.85f, 1.7);

                glowPaint.setStrokeWidth(5f * density);
                glowPaint.setColor(adjustAlpha(color1, 0.7f));
                canvas.drawPath(wave1, glowPaint);
                glowPaint.setColor(adjustAlpha(color2, 0.6f));
                canvas.drawPath(wave2, glowPaint);
                glowPaint.setColor(adjustAlpha(color3, 0.5f));
                canvas.drawPath(wave3, glowPaint);

                wavePaint.setStrokeWidth(2.2f * density);
                wavePaint.setColor(color1);
                canvas.drawPath(wave1, wavePaint);
                wavePaint.setStrokeWidth(1.8f * density);
                wavePaint.setColor(color2);
                canvas.drawPath(wave2, wavePaint);
                wavePaint.setStrokeWidth(1.5f * density);
                wavePaint.setColor(color3);
                canvas.drawPath(wave3, wavePaint);

                if (playing) {
                    phase += 0.095f;
                    if (phase > 100000f) phase = 0f;
                    invalidateSelf();
                }
            }
        }

        private void buildWave(Path path, float startX, float endX, float baseY, float maxAmplitude, double frequency, float phaseValue, double multiplier) {
            path.reset();
            boolean first = true;
            float totalWidth = endX - startX;

            if (totalWidth <= 0) return;

            for (float x = startX; x <= endX; x += 3f) {
                float ratio = (x - startX) / totalWidth; 
                float currentAmplitude = maxAmplitude * ratio; 

                double a = Math.sin(x * frequency + phaseValue);
                double b = Math.sin(x * frequency * 1.8 + phaseValue * multiplier);
                double c = Math.sin(x * frequency * 0.5 - phaseValue * 0.8);

                float y = baseY + (float) ((a * 0.5 + b * 0.35 + c * 0.15) * currentAmplitude);

                if (first) {
                    path.moveTo(x, y);
                    first = false;
                } else {
                    path.lineTo(x, y);
                }
            }
        }

        @Override
        public void setAlpha(int alpha) {}
        @Override
        public void setColorFilter(ColorFilter filter) {}
        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
    
    private int adjustAlpha(int color, float factor) {
        int alpha = Math.round(Color.alpha(color) * factor);
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private int shiftColor(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] = Math.min(1.0f, hsv[2] * factor);
        return Color.HSVToColor(hsv);
    }
}
